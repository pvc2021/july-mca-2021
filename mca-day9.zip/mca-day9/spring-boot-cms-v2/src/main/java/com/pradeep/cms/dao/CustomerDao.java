package com.pradeep.cms.dao;

import java.util.Collection;

import com.pradeep.cms.domain.Customer;

public interface CustomerDao {

	boolean saveCustomer(Customer customer);

	boolean updateCustomer(Customer customer);

	boolean deleteCustomer(int customerId);

	Customer findCustomer(int customerId);

	Collection<Customer> findAllCustomers();

}
