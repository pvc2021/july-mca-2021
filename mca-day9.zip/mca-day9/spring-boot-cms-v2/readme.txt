
Pass h2 database details
===========================


docker run --name cms --env RDS_URL=jdbc:h2:mem:pradeepdb --env RDS_DRIVER_CLASS=org.h2.Driver --env RDS_USERNAME=sa --env RDS_PASSWORD=password --env RDS_DIALECT=org.hibernate.dialect.H2Dialect -p 8080:8080 pradeepch82/customer:1.1




Pass MySQL database details
===========================

docker run --name cms --env RDS_URL=jdbc:mysql://localhost:3306/company --env RDS_DRIVER_CLASS=com.mysql.cj.jdbc.Driver --env RDS_USERNAME=root --env RDS_PASSWORD=admin --env RDS_DIALECT=org.hibernate.dialect.MySQLDialect -p 8080:8080 pradeepch82/customer:1.1
