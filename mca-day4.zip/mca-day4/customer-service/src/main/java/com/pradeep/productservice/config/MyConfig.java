package com.pradeep.productservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class MyConfig {

	
	public MyConfig() {
	System.out.println("=============MyConfig Object created===========");
	}
	
	
	
@Bean
public RestTemplate restTemplate() {
	System.out.println("=============RestTemplate Object created===========");
	return new RestTemplate();
}	

	
}
