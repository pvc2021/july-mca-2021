DROP TABLE IF EXISTS CUSTOMERS;

CREATE TABLE CUSTOMERS (
customerId int primary key,
name text,
pan text,
mobile text,
address text,
dob date
);


