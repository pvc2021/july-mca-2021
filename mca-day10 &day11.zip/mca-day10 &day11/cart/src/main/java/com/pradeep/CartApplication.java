package com.pradeep;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class CartApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartApplication.class, args);
	}

	
	@GetMapping("/carts")
	public List<String> getAllCustomers(){
		return Arrays.asList("Cart1","Cart2","Cart3","Cart4");
	}
	
}
