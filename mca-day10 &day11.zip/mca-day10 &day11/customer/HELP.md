Create a jar 
============================================
mvn clean package install


Build docker image  for product-service and push to docker hub
==============================================================
docker build -t pradeepch82/customer-microservice:1.1 .
docker login
docker push pradeepch82/customer-microservice:1.1

Create docker container from docker image
==============================================================
docker run --name customer -p 8080:8080 pradeepch82/customer-microservice:1.1