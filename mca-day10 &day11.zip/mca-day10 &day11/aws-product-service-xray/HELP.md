

#Changes from H2 Application
 pom.xml  aws-xray-recorder-sdk-spring
 
          <dependency>
			<groupId>com.amazonaws</groupId>
			<artifactId>aws-xray-recorder-sdk-spring</artifactId>
			<version>2.3.0</version>
		</dependency>
 
 
 AwsXrayConfig.java
 XRayInspector.java
 ProductController.java

``
@RestController
@XRayEnabled
public class ProductRestController{
``


Build docker image  for aws-product-service
============================================
docker build -t pradeepch82/aws-product-service-xray:1.1 .



#XRay Daemon
amazon/aws/aws-xray-daemon:1


Pass h2 database details
===========================

docker run --name product --env RDS_URL=jdbc:h2:mem:pradeepdb --env RDS_DRIVER_CLASS=org.h2.Driver --env RDS_USERNAME=sa --env RDS_PASSWORD=password --env RDS_DIALECT=org.hibernate.dialect.H2Dialect -p 8080:8080 pradeepch82/aws-product-service-xray:1.1



Pass MySQL database details
===========================
docker run --name product --env RDS_URL=jdbc:mysql://127.0.0.1:3306/company --env RDS_DRIVER_CLASS=com.mysql.cj.jdbc.Driver --env RDS_USERNAME=root --env RDS_PASSWORD=admin --env RDS_DIALECT=org.hibernate.dialect.MySQL5Dialect -p 8080:8080 pradeepch82/aws-product-service-xray:1.1





Task definition
           Container Def 1  :pradeepch82/aws-product-service-xray:1.1
           Container Def 2  :amazon/aws/aws-xray-daemon:1
           

ECSTaskExecution Role 
                   AWSXRay Full Access


Create Service


