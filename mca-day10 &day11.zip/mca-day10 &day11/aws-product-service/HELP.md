
Build docker image  for aws-product-service
============================================
docker build -t pradeepch82/prod:1.1 .


Pass h2 database details
===========================


docker run --name product --env RDS_URL=jdbc:h2:mem:pradeepdb --env RDS_DRIVER_CLASS=org.h2.Driver --env RDS_USERNAME=sa --env RDS_PASSWORD=password --env RDS_DIALECT=org.hibernate.dialect.H2Dialect -p 8080:8080 pradeepch82/prod:1.1


Pass MySQL database details
===========================

docker run --name product --env RDS_URL=jdbc:mysql://localhost:3306/company --env RDS_DRIVER_CLASS=com.mysql.cj.jdbc.Driver --env RDS_USERNAME=root --env RDS_PASSWORD=admin --env RDS_DIALECT=org.hibernate.dialect.MySQL5Dialect -p 8080:8080 pradeepch82/prod:1.1



arn:aws:ssm:us-east-1:508712564996:parameter/RDS_URL
arn:aws:ssm:us-east-1:508712564996:parameter/RDS_DRIVER_CLASS

arn:aws:ssm:us-east-1:508712564996:parameter/RDS_DIALECT
arn:aws:ssm:us-east-1:508712564996:parameter/RDS_USERNAME
arn:aws:ssm:us-east-1:508712564996:parameter/RDS_PASSWORD
