package com.pradeep.productservice.controller;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.productservice.domain.Product;
import com.pradeep.productservice.service.IProductService;

@RestController
@RequestMapping("/products")
public class ProductRestController {

	Logger logger = Logger.getLogger("com.pradeep.productservice.controller.ProductRestController");

	@Autowired
	private IProductService productService;

	@ResponseStatus(value = HttpStatus.CREATED)
	@PostMapping
	public void addProduct(@RequestBody Product product) {
		productService.addProduct(product);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@PutMapping
	public void updateProduct(@RequestBody Product product) {
		productService.updateProduct(product);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@DeleteMapping(path = "/{productId}")
	public void deleteProduct(@PathVariable("productId") int productId) {
		productService.deleteProduct(productId);
	}

	@GetMapping("/{productId}")
	public Product findProduct(@PathVariable("productId") int productId) {
		logger.info("@@@@@@@ Product Service findProduct method @@@@@@@@@@@");
		return productService.findProductById(productId);
	}

	@GetMapping
	public List<Product> findAllProducts() {
		logger.info("@@@@@@@ Product Service findAllProducts method @@@@@@@@@@@");
		return productService.findAllProducts();
	}

	
	@GetMapping(value="/get-port",produces = {MediaType.TEXT_PLAIN_VALUE})
	public String getPort() {
		return productService.getPort();
	}
}
