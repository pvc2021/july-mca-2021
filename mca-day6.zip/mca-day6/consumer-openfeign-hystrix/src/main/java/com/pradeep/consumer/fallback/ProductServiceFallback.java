package com.pradeep.consumer.fallback;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.pradeep.consumer.proxy.ProductServiceProxy;
import com.pradeep.productservice.domain.Product;

@Service
public class ProductServiceFallback implements ProductServiceProxy{

	
	@Override
	public List<Product> findAllProducts() {
		return Arrays.asList(new Product());
	}
	
	@Override
	public Product findProductById(int productId) {
		return new Product(productId,"Dell",12000.00);
	}
	
	@Override
	public String getPort() {
		// TODO Auto-generated method stub
		return "Default fallbackPort :8080";
	}
		
}
