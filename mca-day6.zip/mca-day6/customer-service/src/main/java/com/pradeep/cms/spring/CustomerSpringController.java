package com.pradeep.cms.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.CustomerService;

@Controller
@RequestMapping("/spring")
//@Component  //default id customerMainApp
public class CustomerSpringController {

		
@Qualifier("mySQLCustomerServiceImpl")
@Autowired
//dependency	
	private CustomerService cs;

	public CustomerSpringController() {
		System.out.println("==========CustomerSpringController created=========");
	}
    
	@RequestMapping("/getallcustomers")
	public String getAllCustomers(ModelMap map) {
		map.addAttribute("customers", cs.findAllCustomers()); //model name
    	
    	return "customerList";  //view name
	}
	
	
	
	@RequestMapping(value="/delete",method = RequestMethod.GET)
	public String deleteCustomerById(@RequestParam("customerId")   int customerId, ModelMap map) {
		
		cs.deleteCustomer(customerId);
		
		map.addAttribute("customers", cs.findAllCustomers()); //model name
    	
    	return "customerList";  //view name
	}
	
	
	@GetMapping("/edit/{id}")
	public String editCustomerById(@PathVariable("id")   int customerId, ModelMap map) {
		
		map.addAttribute("customer", cs.findCustomerById(customerId)); // model name
		
		map.addAttribute("customers", cs.findAllCustomers()); //model name
    	
    	return "editCustomer";  //view name
	}
	
	
	@GetMapping("/newcustomer")
	public String newCustomer(ModelMap map) {
		
		map.addAttribute("customer", new Customer()); // model name
		
		map.addAttribute("customers", cs.findAllCustomers()); //model name
    	
    	return "addCustomer";  //view name
	}
	
	
	
	
	@PostMapping("/updatecustomer")
	public String updateCustomer(@ModelAttribute("customer") Customer customer, ModelMap map) {
		
		cs.updateCustomer(customer);
		
		map.addAttribute("customers", cs.findAllCustomers()); //model name
    	
    	return "customerList";  //view name
	}
	
	@PostMapping("/addcustomer")
	public String addCustomer(@ModelAttribute("customer") Customer customer, ModelMap map) {
		
		cs.saveCustomer(customer);
		
		map.addAttribute("customers", cs.findAllCustomers()); //model name
    	
    	return "customerList";  //view name
	}
	
	
	
	
}
