package com.pradeep.controllers;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.DispatcherServlet;

@Controller
public class TodayController {

	public TodayController() {
	System.out.println("TodayController Created");
	}
		
	@RequestMapping(value="/today",method=RequestMethod.GET)
	@ResponseBody
	public String getToday() {
		return "Today is "+new Date();
	}
	
	
	@RequestMapping(value="/today",method=RequestMethod.POST)
	@ResponseBody
	public String postToday() {
		return "Today is "+new Date();
	}
	
	
	@RequestMapping(value="/today",method=RequestMethod.PUT)
	@ResponseBody
	public String putToday() {
		return "Today is "+new Date();
	}
	
	
	@RequestMapping(value="/today",method=RequestMethod.DELETE)
	@ResponseBody
	public String deleteToday() {
		return "Today is "+new Date();
	}
		
}
