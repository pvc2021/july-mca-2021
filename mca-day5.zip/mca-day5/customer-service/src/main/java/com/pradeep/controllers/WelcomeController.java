package com.pradeep.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/welcome")
public class WelcomeController {

	public WelcomeController() {
	System.out.println("Hello Controller Created");
	}
	
	@RequestMapping(method =RequestMethod.GET)	
	public ModelAndView welcomeAll() {
		return new ModelAndView("welcome", "message", "Practice makes man perfect");    //   /WEB-INF/views/welcome.jsp
	}
		
}
