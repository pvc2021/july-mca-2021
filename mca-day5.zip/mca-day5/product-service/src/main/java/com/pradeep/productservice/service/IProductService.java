package com.pradeep.productservice.service;

import java.util.List;

import com.pradeep.productservice.domain.Product;

public interface IProductService {

	void addProduct(Product product);

	void updateProduct(Product product);

	void deleteProduct(int productId);

	Product findProductById(int productId);

	List<Product> findAllProducts();

}
