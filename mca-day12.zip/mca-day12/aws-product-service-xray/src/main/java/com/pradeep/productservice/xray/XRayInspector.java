package com.pradeep.productservice.xray;

import java.util.Map;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import com.amazonaws.xray.entities.Subsegment;
import com.amazonaws.xray.spring.aop.AbstractXRayInterceptor;

@Aspect
@Component
public class XRayInspector extends AbstractXRayInterceptor {
	
	public XRayInspector() {
	System.out.println("==============XRayInspector created============");
	}
	

	protected Map<String, Map<String, Object>> generateMetaData(ProceedingJoinPoint proceedingJoinPoint,
			Subsegment subsegment) {
		return super.generateMetadata(proceedingJoinPoint, subsegment);
	}

	@Pointcut("@within(com.amazonaws.xray.spring.aop.XRayEnabled) && bean(*)")
	@Override
	public void xrayEnabledClasses() {
		System.out.println("==============xrayEnabledClasses pointcut created============");
		
	}

}
